import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import InputScreen from './components/InputScreen';
import ResultScreen from './components/ResultScreen';
import BottomNav from './components/BottomNav';

export default function App() {
  const [screen, setScreen] = useState<'input' | 'result'>('input');

  return (
    <div className="font-body">
      <AnimatePresence mode="wait">
        {screen === 'input' ? (
          <motion.div
            key="input"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <InputScreen onAnalyze={() => setScreen('result')} />
          </motion.div>
        ) : (
          <motion.div
            key="result"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <ResultScreen onBack={() => setScreen('input')} />
          </motion.div>
        )}
      </AnimatePresence>
      <BottomNav />
    </div>
  );
}
