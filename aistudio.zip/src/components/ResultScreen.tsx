import { motion } from 'motion/react';
import { AlertCircle, TrendingUp, CheckCircle, ArrowRight, ChevronDown, ShieldCheck, ArrowLeft } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export default function ResultScreen({ onBack }: Props) {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden pb-20">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl aspect-square tonal-gradient pointer-events-none -z-0" />

      {/* Header */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-12 py-8 bg-surface/80 backdrop-blur-xl">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-on-surface font-headline font-black tracking-tighter uppercase text-2xl"
        >
          <ArrowLeft size={24} className="text-primary" />
          Paulana Zuplei
        </button>
      </header>

      <main className="relative z-10 pt-40 px-6 max-w-5xl mx-auto flex flex-col gap-16">
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[3.5rem] md:text-[5.5rem] leading-none font-headline font-bold text-primary-container tracking-tighter mb-8"
          >
            Sourcing Analysis
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl text-secondary font-medium tracking-tight"
          >
           Real-time intelligence on your global supply chain. Actionable insights driven by Paulana Zuplei's predictive modeling.
          </motion.p>
        </div>

        {/* Critical Action */}
        <motion.section 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-error-container rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden"
        >
          <div className="absolute -top-10 -right-10 opacity-5">
            <AlertCircle size={300} className="text-error" />
          </div>
          <div className="flex items-center gap-3 mb-10 relative z-10">
            <AlertCircle className="text-error fill-white w-8 h-8" />
            <h3 className="font-headline text-2xl font-bold text-on-error-container uppercase tracking-[0.2em]">Critical Action</h3>
          </div>
          
          <div className="bg-surface-container-lowest rounded-3xl p-8 md:p-10 shadow-sm relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
              <div>
                <h4 className="text-[2rem] font-headline font-bold text-on-background mb-1">Industrial Grade Silicon</h4>
                <p className="text-secondary font-medium">Current Supplier: Apex Materials Corp</p>
              </div>
              <span className="bg-error text-white font-headline text-xs font-bold px-6 py-3 rounded-full uppercase tracking-widest whitespace-nowrap">
                Q3 Contract Renewal
              </span>
            </div>

            <div className="grid md:grid-cols-2 gap-10 mb-10">
              <div className="space-y-3">
                <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Strengths</span>
                <ul className="space-y-2 text-sm text-on-background font-medium">
                  <li>• Consistently High Purity</li>
                  <li>• Long-standing Relationship</li>
                </ul>
              </div>
              <div className="space-y-3">
                <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Weaknesses</span>
                <ul className="space-y-2 text-sm text-error font-medium">
                  <li>• Single Source Risk Alert</li>
                  <li>• 22% Price Variance (YoY)</li>
                </ul>
              </div>
            </div>

            <div className="bg-surface-container-low p-8 rounded-2xl border-l-[6px] border-error mb-10">
              <span className="text-[10px] font-headline font-bold text-error uppercase tracking-[0.2em] block mb-3">Recommendation</span>
              <p className="text-on-background font-medium text-lg leading-relaxed">
                Diversify supply chain immediately. Initiate pilot program with <strong className="font-bold">NovaSil Industries</strong> for 30% of total volume to mitigate single-source vulnerability before Q3 renewal.
              </p>
            </div>

            <button className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs hover:gap-4 transition-all duration-300">
              View Reasoning Trail <ArrowRight size={16} />
            </button>
          </div>
        </motion.section>

        {/* Optimization Opportunity */}
        <motion.section 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-surface-container-highest rounded-[2.5rem] p-8 md:p-12"
        >
          <div className="flex items-center gap-3 mb-10">
            <TrendingUp className="text-primary-container fill-white w-8 h-8" />
            <h3 className="font-headline text-2xl font-bold text-primary-container uppercase tracking-[0.2em]">Optimization Opportunity</h3>
          </div>

          <div className="space-y-8">
            {/* Item 1 */}
            <div className="bg-surface-container-lowest rounded-3xl p-8 md:p-10 shadow-sm hover:shadow-md transition-shadow">
              <div className="mb-8">
                <h4 className="text-[1.75rem] font-headline font-bold text-on-background mb-1">Polycarbonate Resin</h4>
                <p className="text-secondary font-medium">Current Supplier: GlobalPlast Inc.</p>
              </div>

              <div className="grid md:grid-cols-2 gap-10 mb-8 border-b border-outline/10 pb-8">
                <div className="space-y-3">
                  <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Strengths</span>
                  <ul className="space-y-2 text-sm text-on-background font-medium">
                    <li>• Reliable Lead Times</li>
                    <li>• Excellent Documentation</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Weaknesses</span>
                  <ul className="space-y-2 text-sm text-on-background font-medium">
                    <li>• High Freight Costs</li>
                    <li>• Sub-optimal Volume Discounts</li>
                  </ul>
                </div>
              </div>

              <div className="bg-background p-6 rounded-2xl mb-8">
                <span className="text-[10px] font-headline font-bold text-primary-container uppercase tracking-[0.2em] block mb-2">Recommendation</span>
                <p className="text-secondary font-medium leading-relaxed">
                  Renegotiate freight terms or consolidate shipments. Potential 8% savings if volume is shifted entirely to <strong className="text-on-background">EcoPolymers Ltd</strong> due to geographic proximity.
                </p>
              </div>

              <button className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs">
                View Details <ChevronDown size={16} />
              </button>
            </div>

            {/* Item 2 */}
            <div className="bg-surface-container-lowest rounded-3xl p-8 md:p-10 shadow-sm hover:shadow-md transition-shadow">
              <div className="mb-8">
                <h4 className="text-[1.75rem] font-headline font-bold text-on-background mb-1">Anodized Aluminum Parts</h4>
                <p className="text-secondary font-medium">Current Supplier: MetalWorks USA</p>
              </div>

              <div className="grid md:grid-cols-2 gap-10 mb-8 border-b border-outline/10 pb-8">
                <div className="space-y-3">
                  <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Strengths</span>
                  <ul className="space-y-2 text-sm text-on-background font-medium">
                    <li>• Premium Finish Quality</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <span className="text-[10px] font-headline font-bold text-outline uppercase tracking-[0.2em]">Weaknesses</span>
                  <ul className="space-y-2 text-sm text-on-background font-medium">
                    <li>• High Minimum Order Quantity</li>
                  </ul>
                </div>
              </div>

              <div className="bg-background p-6 rounded-2xl mb-8">
                <span className="text-[10px] font-headline font-bold text-primary-container uppercase tracking-[0.2em] block mb-2">Recommendation</span>
                <p className="text-secondary font-medium leading-relaxed">
                  Explore split-sourcing for smaller runs to reduce inventory holding costs. Assess <strong className="text-on-background">Precision Alloy Group</strong> for low-volume orders.
                </p>
              </div>

              <button className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs">
                View Details <ChevronDown size={16} />
              </button>
            </div>
          </div>
        </motion.section>

        {/* Stable Section */}
        <motion.section 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-surface-container-low rounded-[2.5rem] p-8 md:p-12"
        >
          <div className="flex items-center gap-3 mb-8">
            <CheckCircle className="text-secondary w-7 h-7" />
            <h3 className="font-headline text-2xl font-bold text-secondary uppercase tracking-[0.2em]">Stable</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-surface-container-lowest rounded-3xl p-8 border-l-8 border-secondary/20 shadow-sm relative overflow-hidden group">
              <div className="relative z-10">
                <h4 className="text-[1.25rem] font-headline font-bold text-on-background mb-1">Lithium-Ion Cells</h4>
                <p className="text-secondary font-medium mb-6">VoltCore Energy</p>
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary">
                  <ShieldCheck size={16} /> Contract Locked until 2025
                </div>
              </div>
            </div>

            <div className="bg-surface-container-lowest rounded-3xl p-8 border-l-8 border-secondary/20 shadow-sm relative overflow-hidden group">
              <div className="relative z-10">
                <h4 className="text-[1.25rem] font-headline font-bold text-on-background mb-1">Copper Wiring (Spools)</h4>
                <p className="text-secondary font-medium mb-6">KupferTech GmbH</p>
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary">
                  <ShieldCheck size={16} /> Pricing Stable
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}
