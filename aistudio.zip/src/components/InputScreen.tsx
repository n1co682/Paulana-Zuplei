import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, ChevronDown, Braces, ShieldCheck, Scale, ArrowRight, Plus, X } from 'lucide-react';
import StrategicWeightsChart from './StrategicWeightsChart';

const INITIAL_REGULATIONS = [
  "REACH / RoHS Compliance",
  "Conflict Minerals Protocol",
  "Labor Rights Standards (ILO)"
];

interface Props {
  onAnalyze: () => void;
}

export default function InputScreen({ onAnalyze }: Props) {
  const [regulations, setRegulations] = useState<string[]>(INITIAL_REGULATIONS);
  const [newReg, setNewReg] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const handleAddRegulation = () => {
    if (newReg.trim() && !regulations.includes(newReg.trim())) {
      setRegulations([...regulations, newReg.trim()]);
      setNewReg("");
      setIsAdding(false);
    }
  };
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl aspect-square tonal-gradient pointer-events-none -z-0" />

      {/* Navigation */}
      <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-12 py-8 bg-surface/80 backdrop-blur-xl">
        <span className="text-2xl font-black tracking-tighter text-on-surface uppercase font-headline">Paulana Zuplei</span>
      </header>

      <main className="relative z-10 pt-40 pb-32 px-6 max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-24 max-w-3xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[4rem] md:text-[6rem] leading-none font-headline font-bold text-primary-container tracking-tighter mb-6"
          >
            Paulana Zuplei
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl text-secondary font-medium tracking-tight px-4"
          >
            Configure your supply chain parameters, input raw material data, and define compliance bounds for the AI sourcing model.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Raw Material Input */}
          <motion.section 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-surface-container rounded-[2.5rem] p-8 md:p-12 flex flex-col"
          >
            <div className="flex items-center gap-3 mb-4">
              <Braces className="text-primary w-6 h-6" />
              <h2 className="text-xl font-bold font-headline uppercase tracking-wide text-on-surface">Raw Material Input</h2>
            </div>
            <p className="text-secondary font-medium mb-8">Paste JSON/BOM data or upload specifications.</p>
            
            <div className="flex-grow bg-white rounded-2xl p-6 shadow-sm border border-outline/10 min-h-[400px]">
              <textarea 
                placeholder="Paste structural data here..."
                className="w-full h-full bg-transparent border-none focus:ring-0 font-mono text-sm resize-none text-on-background placeholder:text-outline"
              />
            </div>

            <div className="mt-8 flex items-center justify-between">
              <p className="text-[10px] text-outline font-bold uppercase tracking-widest">© 2024 Paulana Zuplei Retro-Futurist Editorial Systems.</p>
              <button className="flex items-center gap-2 text-primary font-bold uppercase tracking-wide text-sm hover:opacity-80 transition-opacity">
                <Upload size={18} />
                Upload File
              </button>
            </div>
          </motion.section>

          {/* Right Column: Other inputs */}
          <div className="flex flex-col gap-8">
            <motion.section 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-surface-container rounded-[2.5rem] p-8 md:p-10"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="text-tertiary w-6 h-6" />
                  <h2 className="text-xl font-bold font-headline uppercase tracking-wide text-on-surface">Compliance Frameworks</h2>
                </div>
                <button 
                  onClick={() => setIsAdding(!isAdding)}
                  className="p-2 bg-white rounded-full text-tertiary hover:bg-tertiary hover:text-white transition-colors shadow-sm"
                >
                  <Plus size={20} />
                </button>
              </div>

              <AnimatePresence>
                {isAdding && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-6 overflow-hidden"
                  >
                    <div className="flex gap-2">
                      <input 
                        type="text"
                        value={newReg}
                        onChange={(e) => setNewReg(e.target.value)}
                        placeholder="Enter regulation name..."
                        className="flex-grow bg-white rounded-xl px-4 py-3 border border-outline/10 text-sm focus:ring-2 focus:ring-tertiary/20"
                        onKeyDown={(e) => e.key === 'Enter' && handleAddRegulation()}
                      />
                      <button 
                        onClick={handleAddRegulation}
                        className="bg-tertiary text-white px-4 rounded-xl font-bold text-xs uppercase tracking-widest"
                      >
                        Add
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative">
                <select className="w-full appearance-none bg-white rounded-2xl px-6 py-4 border border-outline/10 text-secondary font-medium cursor-pointer focus:ring-2 focus:ring-primary/20">
                  <option>Select active regulation standard...</option>
                  {regulations.map((reg, idx) => (
                    <option key={idx} value={reg}>{reg}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 text-outline pointer-events-none" size={20} />
              </div>
            </motion.section>

            {/* Strategic Weights */}
            <motion.section 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-surface-container rounded-[2.5rem] p-8 md:p-10 flex-grow"
            >
              <div className="flex items-center gap-3 mb-4">
                <Scale className="text-secondary w-6 h-6" />
                <h2 className="text-xl font-bold font-headline uppercase tracking-wide text-on-surface">Strategic Weights</h2>
              </div>
              <div className="bg-white/40 rounded-2xl p-4">
                <StrategicWeightsChart />
              </div>
            </motion.section>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-16 flex justify-center">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onAnalyze}
            className="flex items-center gap-4 bg-gradient-to-r from-primary to-primary-container text-white px-10 py-5 rounded-full font-headline font-bold uppercase tracking-widest text-lg shadow-xl shadow-primary/20 hover:shadow-2xl hover:shadow-primary/30 transition-all"
          >
            Analyze Sourcing Options
            <ArrowRight size={24} />
          </motion.button>
        </div>
      </main>
    </div>
  );
}
