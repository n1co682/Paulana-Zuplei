import React, { useState, useRef, useEffect, useMemo } from 'react';

interface DataPoint {
  subject: string;
  value: number;
}

const INITIAL_DATA: DataPoint[] = [
  { subject: 'PRICE', value: 80 },
  { subject: 'QUALITY', value: 85 },
  { subject: 'RESILIENCE', value: 60 },
  { subject: 'ETHICS', value: 70 },
  { subject: 'LEAD TIME', value: 75 },
  { subject: 'CONSOLIDATION', value: 65 },
];

const MAX_VALUE = 100;
const RADIUS = 140;
const CENTER = 200;

export default function StrategicWeightsChart() {
  const [data, setData] = useState<DataPoint[]>(INITIAL_DATA);
  const [activePoint, setActivePoint] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const points = useMemo(() => {
    return data.map((d, i) => {
      const angle = (i * 2 * Math.PI) / data.length - Math.PI / 2;
      const r = (d.value / MAX_VALUE) * RADIUS;
      return {
        x: CENTER + r * Math.cos(angle),
        y: CENTER + r * Math.sin(angle),
        angle,
        subject: d.subject
      };
    });
  }, [data]);

  const gridLevels = [0.2, 0.4, 0.6, 0.8, 1];

  const handlePointerDown = (index: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    setActivePoint(index);
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (activePoint === null || !svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Get position relative to center
    const dx = x - CENTER;
    const dy = y - CENTER;

    // We want to project the mouse position onto the axis of the active point
    const angle = points[activePoint].angle;
    const axisX = Math.cos(angle);
    const axisY = Math.sin(angle);

    // Scalar projection
    let r = (dx * axisX + dy * axisY);
    
    // Convert back to value
    let newValue = (r / RADIUS) * MAX_VALUE;
    newValue = Math.max(0, Math.min(MAX_VALUE, newValue));

    const newData = [...data];
    newData[activePoint] = { ...newData[activePoint], value: Math.round(newValue) };
    setData(newData);
  };

  const handlePointerUp = () => {
    setActivePoint(null);
  };

  const polygonPath = points.map(p => `${p.x},${p.y}`).join(' ');

  return (
    <div className="w-full flex flex-col items-center select-none">
      <div className="relative w-full max-w-[400px] aspect-square">
        <svg 
          ref={svgRef}
          viewBox="0 0 400 400" 
          className="w-full h-full touch-none"
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
        >
          {/* Grid Circles */}
          {gridLevels.map((level) => (
            <path
              key={level}
              className="fill-none stroke-secondary/10"
              d={data.map((_, i) => {
                const angle = (i * 2 * Math.PI) / data.length - Math.PI / 2;
                const r = level * RADIUS;
                const x = CENTER + r * Math.cos(angle);
                const y = CENTER + r * Math.sin(angle);
                return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
              }).join(' ') + ' Z'}
            />
          ))}

          {/* Axis Lines */}
          {data.map((_, i) => {
            const angle = (i * 2 * Math.PI) / data.length - Math.PI / 2;
            const x = CENTER + RADIUS * Math.cos(angle);
            const y = CENTER + RADIUS * Math.sin(angle);
            return (
              <line
                key={i}
                x1={CENTER}
                y1={CENTER}
                x2={x}
                y2={y}
                className="stroke-secondary/10"
              />
            );
          })}

          {/* Labels */}
          {points.map((p, i) => {
            const labelRadius = RADIUS + 40;
            const lx = CENTER + labelRadius * Math.cos(p.angle);
            const ly = CENTER + labelRadius * Math.sin(p.angle);
            return (
                <text
                    key={i}
                    x={lx}
                    y={ly}
                    textAnchor="middle"
                    className="fill-secondary font-headline text-[10px] font-bold uppercase tracking-widest"
                    style={{ dominantBaseline: 'middle' }}
                >
                    {p.subject}
                </text>
            );
          })}

          {/* Data Polygon */}
          <polygon
            points={polygonPath}
            className="fill-primary-container/60 stroke-primary stroke-[3px]"
          />

          {/* Interactive Drag Points */}
          {points.map((p, i) => (
            <circle
              key={i}
              cx={p.x}
              cy={p.y}
              r={activePoint === i ? 8 : 5}
              onPointerDown={handlePointerDown(i)}
              className={`cursor-grab active:cursor-grabbing fill-white stroke-primary stroke-2 transition-all duration-150 ${activePoint === i ? 'scale-125' : 'hover:scale-110'}`}
            />
          ))}
        </svg>
      </div>
    </div>
  );
}
