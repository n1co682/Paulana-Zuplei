import { Search, BarChart3, History, User } from 'lucide-react';

export default function BottomNav() {
  return (
    <nav className="md:hidden bg-white/80 backdrop-blur-2xl fixed bottom-0 w-full z-50 rounded-t-[2rem] border-t border-outline/5 flex justify-around items-center px-6 pb-8 pt-4 shadow-[0_-8px_30px_rgb(0,0,0,0.04)]">
      <button className="flex flex-col items-center justify-center bg-primary-container/10 text-primary-container rounded-2xl px-5 py-2 scale-95 transition-transform">
        <Search size={24} className="mb-0.5" />
        <span className="text-[10px] font-bold uppercase tracking-wider font-headline">Sourcing</span>
      </button>
      <button className="flex flex-col items-center justify-center text-secondary/60 rounded-2xl px-5 py-2 transition-colors">
        <BarChart3 size={24} className="mb-0.5" />
        <span className="text-[10px] font-bold uppercase tracking-wider font-headline">Analysis</span>
      </button>
      <button className="flex flex-col items-center justify-center text-secondary/60 rounded-2xl px-5 py-2 transition-colors">
        <History size={24} className="mb-0.5" />
        <span className="text-[10px] font-bold uppercase tracking-wider font-headline">History</span>
      </button>
      <button className="flex flex-col items-center justify-center text-secondary/60 rounded-2xl px-5 py-2 transition-colors">
        <User size={24} className="mb-0.5" />
        <span className="text-[10px] font-bold uppercase tracking-wider font-headline">Profile</span>
      </button>
    </nav>
  );
}
