from flask import Flask, send_from_directory
import os

app = Flask(__name__, static_folder='dist', static_url_path='')

@app.route('/')
def serve_index():
    return send_from_directory('dist', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    if os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        # Fallback to index.html for SPA routing
        return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    # AI Studio requires port 3000 to be externally accessible
    app.run(host='0.0.0.0', port=3000, debug=True)
