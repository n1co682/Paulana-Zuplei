```markdown
# Design System Document

## 1. Overview & Creative North Star: "The Retro-Futurist Editorial"

This design system is a high-energy, editorial-first framework inspired by the intersection of 1970s sun-drenched nostalgia and crisp, modern digital precision. Our Creative North Star is **"The Retro-Futurist Editorial."**

Unlike standard, grid-bound SaaS platforms, this system embraces **intentional asymmetry** and **kinetic layering**. We treat the screen as a canvas where elements are allowed to overlap, typography serves as a structural pillar, and the "vizz" (effervescence) of the brand is felt through vibrant tonal shifts rather than rigid lines. We move away from the "template" look by using extreme typographic scales and a deep, sophisticated color palette that feels both established and rebellious.

---

## 2. Colors

The color strategy is built on high-contrast relationships between deep "Midnight Blues" and "Sunset Oranges," punctuated by a "Neon Berry" tertiary.

### Color Strategy
- **Primary (#964900 / #F58220):** Our "Solar Energy." Used for high-priority actions and brand-heavy moments.
- **Secondary (#486081 / #001E3C):** Our "Carbonated Depth." Provides the sophisticated, grounded foundation that makes the oranges pop.
- **Tertiary (#B8006C / #D4007D):** The "Flavor Accent." Use sparingly for delightful surprises, notifications, or specific high-intent UI paths.

### The "No-Line" Rule
To achieve a premium, editorial feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined through:
- **Tonal Shifts:** Using `surface_container_low` against a `surface` background.
- **Negative Space:** Using large blocks of padding to allow content to breathe and define its own territory.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-translucent materials.
- **Base Layer:** `surface` (#f8f9ff).
- **Secondary Layer:** `surface_container_low` (#eff4ff).
- **Elevated Components:** `surface_container_highest` (#d3e3ff).
- **The Glass & Gradient Rule:** For hero sections and primary CTAs, use linear gradients transitioning from `primary` to `primary_container`. For floating navigation menus, utilize **Glassmorphism**: a semi-transparent `surface` color with a 20px-40px backdrop-blur to allow the vibrant brand colors to bleed through subtly.

---

## 3. Typography

The typography is a dialogue between two distinct personalities: the geometric, avant-garde **Space Grotesk** and the clean, high-performance **Plus Jakarta Sans**.

### Headline & Display (Space Grotesk)
Space Grotesk provides a retro-tech vibe. 
- Use **Display-LG (3.5rem)** for hero messaging, often with tight letter-spacing (-0.02em) to create an "Editorial Impact."
- Headlines should be used as structural elements, sometimes intentionally overlapping with images or surface containers to break the "boxed-in" feel.

### Body & Title (Plus Jakarta Sans)
Plus Jakarta Sans is our workhorse.
- **Title-LG (1.375rem)** handles sub-headers with a weight that balances the energy of the display type.
- **Body-MD (0.875rem)** is the default for readability. We use high-contrast sizing (large displays vs. small body text) to create a premium, fashion-magazine hierarchy.

---

## 4. Elevation & Depth

We eschew traditional "box shadows" in favor of **Tonal Layering** and **Ambient Light**.

- **The Layering Principle:** Depth is achieved by "stacking." Place a `surface_container_lowest` card on top of a `surface_container_low` background. The shift in color provides a soft, natural lift.
- **Ambient Shadows:** When a floating effect is required (e.g., a modal or a floating action button), shadows must be extra-diffused. Use a 32px-48px blur with 6% opacity. The shadow color should not be grey; use a tinted version of `on_surface` (a deep blue tint) to maintain color harmony.
- **The "Ghost Border" Fallback:** If a boundary is strictly required for accessibility (e.g., in a high-density data grid), use the `outline_variant` token at **15% opacity**. This creates a hint of a boundary without the "cheapness" of a hard line.
- **Kinetic Overlap:** Encourage elements (like images or floating chips) to break the container bounds. A `primary_container` element should occasionally "peek" out from its parent `surface` to create visual tension and energy.

---

## 5. Components

### Buttons
- **Primary:** Rounded-full (`9999px`). Use a gradient from `primary` to `primary_container`. Typography should be `label-md` in all-caps with 0.05em tracking for a "sporty" feel.
- **Secondary:** Transparent background with a `Ghost Border` and `primary` text.
- **Tertiary:** No border, no background. Underline on hover using a 2px `tertiary` stroke.

### Cards & Lists
- **Cards:** Strictly no borders. Use `surface_container` tiers to separate. Apply a `xl` (1.5rem) corner radius for a friendly, modern feel.
- **Lists:** Forbid divider lines. Separate list items using `8px` of vertical white space or a subtle hover state shift to `surface_bright`.

### Inputs & Interaction
- **Input Fields:** Use `surface_container_low` as the fill. On focus, the field should transition to `surface_container_highest` with a 2px bottom-only stroke in `tertiary`. 
- **Chips:** These are our "Flavor Bubbles." Use `secondary_container` for background with `on_secondary_container` text. Use `full` roundedness.

### Tooltips & Overlays
- Always use the **Glassmorphism** rule. A `surface` fill at 80% opacity with a heavy backdrop blur. This keeps the interface feeling "effervescent" and light.

---

## 6. Do’s and Don’ts

### Do
- **Do** use intentional asymmetry. Offset images and text blocks to create a dynamic rhythm.
- **Do** lean into the "Midnight Blue" (`on_background`) for text. It feels more premium and organic than pure black.
- **Do** use the Spacing Scale aggressively. Wide margins (e.g., 80px-120px on desktop) are what separate "high-end" from "standard."

### Don't
- **Don't** use 100% opaque, high-contrast borders. It kills the "Retro-Futurist" flow.
- **Don't** use standard "drop shadows" (0, 2, 4, black). They look dated and muddy.
- **Don't** center-align everything. The system thrives on a strong left-aligned axis with "floating" accents on the right.
- **Don't** be afraid of the Pink (`tertiary`). Use it to draw the eye to the most important conversion point on the page.

---

**Director’s Note:** Remember, this design system isn't just about utility; it’s about *vibe*. Every interaction should feel as refreshing and energetic as the brand it represents. If a layout feels boring, increase the font size of the headline and add more white space.```